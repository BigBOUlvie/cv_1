import sys
import cv2  
import numpy as np  
import pandas as pd  
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QHBoxLayout, QVBoxLayout, QLabel, QFileDialog, QTextEdit  # Import PyQt5 widgets for GUI creation
from PyQt5.QtGui import QImage, QPixmap  
from PyQt5.QtCore import QTimer  
from ultralytics import YOLO  
from collections import deque  

class VideoProcessor(QWidget):
    def __init__(self):
        super().__init__()
 
        self.initUI()  # Initialize the user interface
        self.video_capture = None  # Video capture object initialized to None
        self.timer = QTimer()  # Create a QTimer object
        self.timer.timeout.connect(self.show_frame)  # Connect the timeout signal to the show_frame method
        self.model = None  # YOLO model initialized to None
        self.model_path = ""  # Path to the YOLO model file
        self.save_path = ""  # Path to save the output data
        self.frame_number = 0  # Frame number counter initialized to 0
        self.prev_positions = {}  # Dictionary to store previous positions of detected objects
        self.vehicle_window = deque(maxlen=25)  # Sliding window to keep track of vehicle IDs
        self.df = pd.DataFrame(columns=['Frame Number', 'Flow (vehicles/s)', 'Density (vehicles/m)'])  # DataFrame to store the output data
 
    def initUI(self):
        self.setWindowTitle('Video Processor')  # Set the window title
 
        # Set up the main layout
        main_layout = QVBoxLayout()
 
        # Create a label to display the video frames
        self.video_label = QLabel(self)
        main_layout.addWidget(self.video_label)
 
        # Create a horizontal layout for buttons and info display
        h_layout = QHBoxLayout()

        # Create buttons for opening video, selecting model, and saving path
        self.open_button = QPushButton('选择视频', self)
        self.open_button.clicked.connect(self.open_video)
        h_layout.addWidget(self.open_button)
 
        self.model_button = QPushButton('选择模型', self)
        self.model_button.clicked.connect(self.select_model)
        h_layout.addWidget(self.model_button)
        
        self.save_button = QPushButton('选择保存路径', self)
        self.save_button.clicked.connect(self.select_save_path)
        h_layout.addWidget(self.save_button)

        main_layout.addLayout(h_layout)

        # Create a text area to display selected information
        self.info_display = QTextEdit(self)
        self.info_display.setReadOnly(True)
        main_layout.addWidget(self.info_display)
 
        # Create a start button to begin video processing
        self.start_button = QPushButton('开始检测', self)
        self.start_button.clicked.connect(self.start_video)
        main_layout.addWidget(self.start_button)
 
        self.setLayout(main_layout)  # Set the main layout for the window
 
    def select_model(self):
        # Open a file dialog to select the YOLO model file
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getOpenFileName(self, "选择YOLO模型文件", "", "YOLO Model Files (*.pt);;All Files (*)", options=options)
        if file_name:
            self.model_path = file_name
            self.model = YOLO(self.model_path)  # Load the selected YOLO model
            self.info_display.append("选择的模型文件: " + file_name)
 
    def open_video(self):
        # Open a file dialog to select the video file
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getOpenFileName(self, "选择视频文件", "", "Video Files (*.mp4 *.avi *.mov);;All Files (*)", options=options)
        if file_name:
            self.video_capture = cv2.VideoCapture(file_name)  # Open the selected video file
            self.info_display.append("选择的视频文件: " + file_name)

    def select_save_path(self):
        # Open a file dialog to select the save path for the output data
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getSaveFileName(self, "选择保存文件", "", "Excel Files (*.xlsx);;All Files (*)", options=options)
        if file_name:
            self.save_path = file_name
            self.info_display.append("选择的保存路径: " + file_name)

    def start_video(self):
        # Start the video processing if a video file is opened
        if self.video_capture and self.video_capture.isOpened():
            self.timer.start(30)  # Start the timer with a 30ms interval
            self.info_display.append("视频检测已开始")

    def show_frame(self):
        # Read a frame from the video
        ret, frame = self.video_capture.read()
        if not ret:
            self.timer.stop()  # Stop the timer if no frames are left
            self.save_data_and_close()  # Save the data and close the window
            return

        # Process the frame with the YOLO model to detect and track objects
        results = self.model.track(frame, persist=True)
        a = results[0].plot()
        track_ids = results[0].boxes.id.int().cpu().tolist()
        boxes = results[0].boxes.xywh.cpu()

        # Calculate the number of vehicles in the current frame
        current_frame_vehicle_count = len(track_ids)
        current_ids = set(track_ids)
        self.vehicle_window.append(current_ids)
        unique_id = set().union(*self.vehicle_window)
        flow_rate = len(unique_id)  # Calculate the flow rate
        vehicle_density = current_frame_vehicle_count  # Calculate the vehicle density

        # Store the frame number, flow rate, and vehicle density in the DataFrame
        row_data = [self.frame_number, flow_rate, vehicle_density]
        self.df.loc[len(self.df)] = row_data

        # Convert the frame to RGB format for display
        frame_rgb = cv2.cvtColor(a, cv2.COLOR_BGR2RGB)
        h, w, ch = frame_rgb.shape
        bytes_per_line = ch * w
        qt_image = QImage(frame_rgb.data, w, h, bytes_per_line, QImage.Format_RGB888)
        pixmap = QPixmap.fromImage(qt_image)
        self.video_label.setPixmap(pixmap)  # Display the frame in the video label

        self.frame_number += 1  # Increment the frame number

    def save_data_and_close(self):
        # Save the DataFrame to an Excel file and close the window
        if self.save_path:
            self.df.to_excel(self.save_path, index=False)
        else:
            self.df.to_excel('cds540_test.xlsx', index=False)
        self.info_display.append("数据已保存并关闭窗口")
        self.close()

    def closeEvent(self, event):
        # Release the video capture object when the window is closed
        if self.video_capture:
            self.video_capture.release()
        event.accept()
 
if __name__ == '__main__':
    # Create and run the application
    app = QApplication(sys.argv)
    ex = VideoProcessor()
    ex.show()
    sys.exit(app.exec_())