
# GGB - Video Traffic Flow Analysis Tool
## Overview
GGB is a tool designed for analyzing traffic flow density in videos. By processing video frames, it can calculate the number of vehicles, vehicle flow rate (vehicles/s), and vehicle density (vehicles/m) for each frame. This tool is particularly suitable for analyzing short videos (recommended duration not exceeding 30 seconds) and allows users to load custom models and specify file save paths.

## Usage Instructions
### 1. Create a Conda Virtual Environment
First, you need to create a Conda virtual environment to install and run GGB. Open your command-line tool and enter the following command:

conda create --name GGB python=3.8
### 2. Install Dependencies
In the activated virtual environment, install the required dependencies for the project using pip. These dependencies are listed in the requirements.txt file.

pip install -r requirements.txt
### 3. Run GGB
After installation, you can run the main program 111222.py from the terminal or directly.

python 111222.py
### 4. Select the Video to Process, Choose the Model (You Can Load Your Own Model), and Specify the Data Save Path (You Can Save Files in a Custom Way)
Videos processed here should ideally not exceed 30 seconds in duration;
The saved data includes: Frame Number (indicating the nth frame of the video), Flow (vehicles/s), and Density (vehicles/m).